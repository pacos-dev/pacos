# SonarQube export

Point-in-time export of the selected SonarQube project.
- `quality-gate.json`: Quality Gate status and conditions.
- `issues.json`: all unresolved issues returned by the paginated API.
- `measures.json`: selected project metrics.
- `sonar-version.txt`: SonarQube server version.
- `hotspots.json`: first page (up to 500) of hotspots awaiting review, when enabled and permitted.

The archive does not contain the API token. Issue data can include source snippets and internal paths; review before sharing outside the team.
